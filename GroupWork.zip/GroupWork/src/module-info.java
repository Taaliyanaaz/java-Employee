module GroupWork {
	requires org.apache.logging.log4j;
}